import React from 'react'

export const Hello = () => <h1>Hello World</h1>

//export default Hello