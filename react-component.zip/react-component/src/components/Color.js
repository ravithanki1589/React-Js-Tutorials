import React from 'react'

function Color() {
  return <h1>Red Color</h1>
}

export default Color